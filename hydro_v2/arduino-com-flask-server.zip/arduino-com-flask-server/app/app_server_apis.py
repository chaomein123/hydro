from flask import request
import os
import json

def set_variables(payload):
    url = os.getenv('API_URL')+f"/update-variables/:{os.getenv('PLANT_ID')}"
    payload = json.dumps(payload)
    response = requests.request("PUT", url, headers=headers, data=payload)
    return response

def send_notification(payload):
    payload["user_id"] = os.getenv("USER_ID")
    url = os.getenv('API_URL')+"/send-specific-notification"
    payload = json.dumps(payload)
    response = requests.request("POST", url, headers=headers, data=payload)
    return response

