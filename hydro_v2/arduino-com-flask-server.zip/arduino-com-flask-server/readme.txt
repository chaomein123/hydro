flask = "*"
pyserial = "*"
python-dotenv = "*"

pip install flask
pip install pyserial
pip install paho-mqtt

update in .flaskenv
USER_ID
PLANT_ID

run using flask run