receive_codes = {
    "h":"harvest",
    "c":"clogged",
    "w":"water_res",
    "u":"ph_up",
    "d":"ph_down",
    "b":"nut_b",
    "a":"nut_a",
    "p": "All parameters setup"
}

send_codes = {
    "Tip Burn": "T",
    "Brown Spots": "B",
    "Yellowing and Wilting": "Y",
    "Gray White": "N"
}